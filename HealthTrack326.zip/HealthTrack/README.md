# HealthTrack

This project is organised into shared and page-specific front-end files.

## Folder structure
- `css/common.css`: shared layout, components and responsive styles.
- `css/<page>.css`: styles specific to each webpage.
- `js/common.js`: shared utilities, navigation, authentication/session helpers, notifications and tracker helpers.
- `js/<page>.js`: JavaScript functions and initialisation for that webpage.

## Pages
`index`, `login`, `signup`, `dashboard`, `add-report`, `summary`, `records`, `daily-tracking`, `water`, `steps`, `bmi`, and `profile`.

Open `index.html` to start the website. Keep the `css` and `js` folders alongside the HTML files.

The existing HTML, CSS rules and JavaScript function bodies were moved into a shared/page-specific structure; this reorganisation is intended to preserve the existing website behaviour and design.
